"""Build Guthli from Allo 1.0.3's variable TTF. See README.md for the pinned source."""
import argparse
import math
from pathlib import Path

from fontTools import subset
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables.TupleVariation import TupleVariation
from fontTools.ttLib.tables._g_l_y_f import GlyphCoordinates
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.otlLib.builder import buildStatTable


def seed(glyph):
    """A tilted pit with a tight upper point and a round lower shoulder."""
    x = (glyph.xMin + glyph.xMax) / 2
    y = (glyph.yMin + glyph.yMax) / 2
    rx = (glyph.xMax - glyph.xMin) / 2
    ry = (glyph.yMax - glyph.yMin) / 2

    def at(px, py):
        return round(x + px * rx), round(y + py * ry)

    pen = TTGlyphPen(None)
    pen.moveTo(at(.77, 1.09))
    pen.qCurveTo(at(1.09, .17), at(.51, -.64))
    pen.qCurveTo(at(.13, -1.16), at(-.45, -.91))
    pen.qCurveTo(at(-1.12, -.59), at(-.77, .21))
    pen.qCurveTo(at(-.53, .78), at(.77, 1.09))
    pen.closePath()
    return pen.glyph()


def draw_serif(contour, flags, i, result):
    """Re-cut a rounded free stem end into an integral, asymmetric bracket."""
    count = len(contour)
    indices = [(i + j) % count for j in range(-3, 5)]
    root_a, ctrl_a, ctrl_b, tip_a, tip_b, ctrl_c, ctrl_d, root_b = indices
    if [flags[j] & 1 for j in indices] != [1,0,0,1,1,0,0,1]:
        return False
    ax, y = contour[tip_a]
    bx, by = contour[tip_b]
    if by != y or not 80 <= abs(bx-ax) <= 310:
        return False
    ra, rb = contour[root_a], contour[root_b]
    if (ra[1]-y)*(rb[1]-y) <= 0 or max(abs(ra[1]-y),abs(rb[1]-y)) > 37:
        return False
    # Leave the free ends of crossbars and the top of the A untouched.
    if y not in (0, 1490, 1540) and not 1050 <= y <= 1130:
        return False
    if abs(ra[0]-ax)>42 or abs(rb[0]-bx)>42:
        return False
    inward = 1 if ra[1] > y else -1
    for root, shoulder, outer, tip, base, side, run in (
        (root_a, ctrl_a, ctrl_b, tip_a, ra, -1 if ax < bx else 1, (i-4)%count),
        (root_b, ctrl_d, ctrl_c, tip_b, rb, 1 if ax < bx else -1, (i+5)%count),
    ):
        nx, ny = contour[run]
        depth = min(149, abs(ny-y)*.46)
        if depth < 39:
            return False
    updates = {}
    for root, shoulder, outer, tip, base, side, run in (
        (root_a, ctrl_a, ctrl_b, tip_a, ra, -1 if ax < bx else 1, (i-4)%count),
        (root_b, ctrl_d, ctrl_c, tip_b, rb, 1 if ax < bx else -1, (i+5)%count),
    ):
        nx, ny = contour[run]
        depth = min(149, abs(ny-y)*.46)
        slope = max(-.55,min(.55,(nx-base[0])/(ny-base[1]))) if ny!=base[1] else 0
        reach = 112 if side*inward < 0 else 76
        x = base[0] + slope*(y-base[1])
        updates[root] = (x+slope*inward*depth,y+inward*depth)
        updates[shoulder] = (x+slope*inward*55,y+inward*55)
        updates[outer] = (x+side*(reach-15),y+inward*40)
        updates[tip] = (x+side*reach,y+inward*(5 if side==-1 else 0))
    for idx, point in updates.items():
        result[idx] = point
    return True


def make_variation(glyph, glyph_name):
    coords = list(glyph.coordinates)
    output = list(coords)
    start = 0
    terminals = 0
    for end in glyph.endPtsOfContours:
        contour = coords[start:end+1]
        flags = glyph.flags[start:end+1]
        edited = list(contour)
        for i in range(len(contour)):
            if glyph_name == 'A' and contour[i][1] > 1000:
                continue
            if draw_serif(contour, flags, i, edited):
                terminals += 1
        output[start:end+1] = edited
        start=end+1
    # Redistribute the stroke contrast towards the sides of bowls. This keeps
    # the points at both extrema fixed and opens the top and bottom counters.
    span = glyph.yMax-glyph.yMin
    for i, (x,y) in enumerate(output):
        t = (y-glyph.yMin)/span if span else 0
        shift = -min(64,span*.049)*math.sin(2*math.pi*t)
        output[i] = (round(x),round(y+shift))
    deltas = [(x-a,y-b) for (x,y),(a,b) in zip(output,coords)]
    return deltas,terminals


def build(source, dest):
    font = TTFont(source, recalcTimestamp=False)
    opts = subset.Options()
    opts.layout_features = ['kern','mark','mkmk','ccmp','locl','tnum']
    opts.glyph_names = True
    selection = subset.Subsetter(options=opts)
    codes = [*range(32,0x250), *range(0x300,0x370), *range(0x2000,0x2070),0x20ac,0x20b9]
    selection.populate(unicodes=codes)
    selection.subset(font)
    font = instantiateVariableFont(font,{'opsz':24,'wght':430,'ROND':8},static=True)
    for tag in ('STAT','DSIG'):
        if tag in font:
            del font[tag]
    glyf = font['glyf']
    for name in ('dotaccentcomb','period'):
        glyph = glyf[name]
        glyf[name] = seed(glyph)
    names = font['name']
    # Preserve source copyright, designers, trademarks and OFL records. Replace
    # family identifiers and stale variation labels at every locale/platform.
    keep = {0,7,8,9,11,12,13,14}
    names.names = [n for n in names.names if n.nameID in keep]
    for id,value in {1:'Guthli',2:'Regular',3:'Guthli 0.1 Regular',4:'Guthli Regular',
                     5:'Version 0.100',6:'Guthli-Regular',10:'A personal display family derived from Allo, with a continuous serif axis.',
                     16:'Guthli',17:'Regular'}.items():
        names.setName(value,id,3,1,0x409)
    font['OS/2'].usWeightClass=400
    font['head'].fontRevision=.1
    variations={}
    total=0
    # Accented composites inherit their base letter's deltas automatically.
    cmap=font.getBestCmap()
    letters={n for code,n in cmap.items() if chr(code).isalpha() and code<0x250}
    letters |= {'idotless','jdotless'}
    for name in letters:
        g=glyf[name]
        if g.isComposite() or g.numberOfContours<=0:
            continue
        g.coordinates = GlyphCoordinates([(round(x),round(y)) for x,y in g.coordinates])
        g.recalcBounds(glyf)
        delta,n=make_variation(g,name)
        if any(dx or dy for dx,dy in delta):
            variations[name]=[TupleVariation({'SERF':(0,1,1)},delta+[(0,0)]*4)]
        total+=n
    fb=FontBuilder(font=font)
    fb.setupFvar([('SERF',0,0,100,'Serif reach')],[
        {'location':{'SERF':v},'stylename':n} for v,n in [(0,'Sans'),(52,'Half-serif'),(100,'Serif')]])
    fb.setupGvar(variations)
    buildStatTable(font,[dict(tag='SERF',name='Serif reach',values=[
        dict(value=0,name='Sans',flags=2),dict(value=52,name='Half-serif'),dict(value=100,name='Serif')])])
    dest.mkdir(exist_ok=True,parents=True)
    font.save(dest/'Guthli.ttf')
    font.flavor='woff2'
    font.save(dest/'Guthli.woff2')
    print(f'{len(cmap)} Unicode characters, {len(variations)} varying base glyphs, {total} recut stem ends.')


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('source',type=Path)
    parser.add_argument('destination',type=Path)
    args=parser.parse_args()
    build(args.source,args.destination)
