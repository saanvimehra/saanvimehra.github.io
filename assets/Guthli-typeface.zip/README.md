# Guthli 0.1

Guthli is a variable display typeface made for Saanvi Mehra’s personal website. Its name comes from the Hindi word for a fruit stone. The seed-shaped tittle on i and j, asymmetric terminal brackets, and changing bowl contrast are specific to this cut.

The outlines start from Josh Puckett’s Allo 1.0.3 (itself crediting the Inter Project). The starting design is fixed at optical size 24, weight 430 and roundness 8. The new SERF axis spans 0 to 100. Its named instances are Sans (0), Half-serif (52) and Serif (100). Widths stay constant when you change the axis. This first cut covers 374 Unicode code points, primarily Latin, marks and punctuation. It has one upright weight. The SIL Open Font License and source credits accompany the fonts.

## Use it

Double-click Guthli.ttf on a Mac and select Install in Font Book. In a design app that supports variable fonts, choose Guthli and adjust Serif reach. For the web, serve Guthli.woff2 with your other assets.

```css
@font-face {
  font-family: Guthli;
  src: url("Guthli.woff2") format("woff2");
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}
.wordmark {
  font-family: Guthli, sans-serif;
  font-variation-settings: "SERF" 52;
}
```

## Rebuild from source

Use Python 3.10 or later with fontTools 4.68.0 and Brotli. Download the upstream Allo repository at commit 60992c5e12a4ad5cad41c54cd8dba370163a4828. Run the following from the directory with this recipe.

```sh
python3 -m venv .venv
.venv/bin/pip install 'fonttools[woff]==4.68.0'
.venv/bin/python build_font.py /path/to/allo/fonts/variable/AlloVariable.ttf build
```

The recipe draws the pit from quadratic curves, reshapes compatible terminal points, and builds a TrueType gvar table for real outline interpolation. Change the two reach values in draw_serif to alter the balance of the feet. Change the control points in seed to redraw the tittle.

[Allo source](https://github.com/joshpuckett/allo/tree/60992c5e12a4ad5cad41c54cd8dba370163a4828) · [गुठली in Hindwi](https://www.hindwi.org/hindi-dictionary/meaning-of-guthlii)
