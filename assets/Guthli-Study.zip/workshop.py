"""Build the Guthli 0.2 study from the licensed 0.1 variable font."""
import argparse
from pathlib import Path
import unicodedata

from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.otlLib.builder import buildLookup, buildPairPosGlyphs, buildValue
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables.TupleVariation import TupleVariation
from fontTools.varLib.instancer import instantiateVariableFont
from build_font import make_variation


def draw_e(reach):
    """An open mouth and a pen-cut tip; keep the compact 0.2.1 advance."""
    s = reach
    p = TTGlyphPen(None)
    p.moveTo((928 + 12*s, 273 + 23*s))
    p.qCurveTo((819, -22), (517, -22))
    p.qCurveTo((307, -22), (176, 125))
    p.qCurveTo((50, 263), (50, 520))
    p.qCurveTo((50, 773), (187, 931))
    p.qCurveTo((319, 1094), (535, 1094))
    p.qCurveTo((737, 1094), (853, 959))
    p.qCurveTo((959, 837), (959, 603))
    p.lineTo((958, 531))
    p.lineTo((230, 510))
    p.qCurveTo((233, 310), (329, 207 - 12*s))
    p.qCurveTo((410, 120 - 23*s), (545, 120 - 23*s))
    p.qCurveTo((736, 120 - 23*s), (853, 292 + 19*s))
    p.qCurveTo((883, 336 + 20*s), (898, 356 + 27*s))
    p.closePath()
    p.moveTo((234, 618 - 8*s))
    p.lineTo((786, 637 - 7*s))
    p.qCurveTo((777, 964 + 24*s), (525, 964 + 24*s))
    p.qCurveTo((287, 964 + 24*s), (234, 618 - 8*s))
    p.closePath()
    return p.glyph()


def entry(pen, left, right, reach):
    """Begin an upright with a left-facing nib and a shallow sloped cap."""
    nib = 38 + 26*reach
    pen.moveTo((left, 930))
    pen.qCurveTo((left, 1011), (left - nib, 1023))
    pen.lineTo((left - nib, 1054))
    pen.lineTo((right - 9, 1087))
    pen.qCurveTo((right, 1088), (right, 1075))


def foot(pen, left, right, baseline, reach, spread=1):
    """Travel clockwise around a short, bracketed stem foot."""
    extension = (40 + 37*reach) * spread
    pen.lineTo((right, baseline + 99))
    pen.qCurveTo((right, baseline + 48), (right + extension, baseline + 32))
    pen.lineTo((right + extension, baseline))
    pen.lineTo((left - extension, baseline))
    pen.lineTo((left - extension, baseline + 32))
    pen.qCurveTo((left, baseline + 45), (left, baseline + 99))


def draw_r(s):
    p = TTGlyphPen(None)
    entry(p, 129, 297, s)
    p.lineTo((297, 850))
    p.qCurveTo((384, 1093), (565, 1093))
    p.qCurveTo((620, 1093), (657 + 8*s, 1069))
    p.lineTo((629 + 6*s, 909 - 9*s))
    p.qCurveTo((587, 932), (538, 932))
    p.qCurveTo((395, 932), (329, 751))
    p.qCurveTo((307, 689), (307, 604))
    foot(p, 129, 307, 0, s)
    p.closePath()
    return p.glyph()


def draw_m(s):
    p = TTGlyphPen(None)
    entry(p, 126, 298, s)
    p.lineTo((298, 889))
    p.qCurveTo((416, 1093), (613, 1093))
    p.qCurveTo((821, 1093), (889, 884))
    p.qCurveTo((1010, 1093), (1215, 1093))
    p.qCurveTo((1538, 1093), (1538, 710))
    foot(p, 1361, 1538, 0, s, .83)
    p.lineTo((1361, 695))
    p.qCurveTo((1361, 951 + 16*s), (1177, 951 + 16*s))
    p.qCurveTo((1069, 951 + 16*s), (995, 866))
    p.qCurveTo((912, 770), (912, 626))
    foot(p, 736, 912, 0, s, .72)
    p.lineTo((736, 701))
    p.qCurveTo((736, 951 + 16*s), (554, 951 + 16*s))
    p.qCurveTo((452, 951 + 16*s), (378, 866))
    p.qCurveTo((303, 779), (303, 630))
    foot(p, 126, 303, 0, s, .83)
    p.closePath()
    return p.glyph()


def draw_p(s):
    p = TTGlyphPen(None)
    entry(p, 124, 298, s)
    p.lineTo((298, 910))
    p.qCurveTo((430, 1094), (641, 1094))
    p.qCurveTo((838, 1094), (967, 951))
    p.qCurveTo((1097, 805), (1097, 554))
    p.qCurveTo((1097, 307), (962, 142))
    p.qCurveTo((830, -20), (620, -20))
    p.qCurveTo((425, -20), (302, 139))
    foot(p, 124, 302, -390, s)
    p.closePath()
    p.moveTo((300, 509))
    p.qCurveTo((300, 327), (381, 225))
    p.qCurveTo((458, 124 - 18*s), (596, 124 - 18*s))
    p.qCurveTo((730, 124 - 18*s), (820, 241))
    p.qCurveTo((911, 361), (911, 557))
    p.qCurveTo((911, 747), (831, 849))
    p.qCurveTo((753, 953 + 18*s), (620, 953 + 18*s))
    p.qCurveTo((481, 953 + 18*s), (389, 833))
    p.qCurveTo((300, 718), (300, 556))
    p.closePath()
    return p.glyph()


def draw_a(s):
    p = TTGlyphPen(None)
    p.moveTo((753, 141))
    p.qCurveTo((635, -20), (434, -20))
    p.qCurveTo((72, -20), (72, 277))
    p.qCurveTo((72, 520), (414, 610))
    p.qCurveTo((582, 653), (750, 672))
    p.lineTo((750, 742))
    p.qCurveTo((750, 960 + 18*s), (537, 960 + 18*s))
    p.qCurveTo((350, 960 + 18*s), (266, 763))
    p.lineTo((154 - 9*s, 797))
    p.lineTo((173 - 15*s, 930 + 21*s))
    p.qCurveTo((317, 1093), (550, 1093))
    p.qCurveTo((927, 1093), (927, 726))
    p.lineTo((927, 175))
    p.qCurveTo((927, 58), (996 + 9*s, 67))
    p.lineTo((1001 + 9*s, 29))
    p.qCurveTo((948, -9), (881, -9))
    p.qCurveTo((771, -9), (753, 141))
    p.closePath()
    p.moveTo((255, 287))
    p.qCurveTo((255, 120 - 19*s), (457, 120 - 19*s))
    p.qCurveTo((595, 120 - 19*s), (681, 228))
    p.qCurveTo((751, 316), (751, 448))
    p.lineTo((751, 561))
    p.qCurveTo((581, 538), (475, 500))
    p.qCurveTo((255, 430), (255, 287))
    p.closePath()
    return p.glyph()


def draw_t(reach):
    """A sloping pen entry, short asymmetric bar, and open, upturned foot."""
    s = reach
    p = TTGlyphPen(None)
    p.moveTo((225 - 22*s, 1327))
    p.qCurveTo((296 - 14*s, 1353), (373 + 15*s, 1430))
    p.lineTo((388, 1415))
    p.lineTo((388, 1064))
    p.qCurveTo((496, 1064), (605 + 22*s, 1083 + 9*s))
    p.lineTo((595 + 12*s, 982 + 8*s))
    p.qCurveTo((511, 950 + 11*s), (388, 950 + 11*s))
    p.lineTo((388, 342))
    p.qCurveTo((388, 153 - 20*s), (509, 153 - 20*s))
    p.qCurveTo((561, 153 - 20*s), (625, 211 + 24*s))
    p.lineTo((648, 146 + 13*s))
    p.qCurveTo((569, -13), (434, -13))
    p.qCurveTo((214 - 7*s, -13), (214 - 7*s, 287))
    p.lineTo((214 - 7*s, 950 + 11*s))
    p.lineTo((55 - 19*s, 950 + 11*s))
    p.lineTo((62 - 20*s, 1040))
    p.qCurveTo((156, 1048), (219, 1062))
    p.closePath()
    return p.glyph()


def draw_g(reach):
    """Single-storey bowl, small rising ear, and a left-sweeping descender."""
    s = reach
    p = TTGlyphPen(None)
    p.moveTo((564, 1098))
    p.qCurveTo((765, 1098), (864, 934 - 12*s))
    p.qCurveTo((899, 1037), (1009 + 35*s, 1102 + 20*s))
    p.lineTo((1054 + 28*s, 1071 + 12*s))
    p.qCurveTo((1027, 996), (1027, 877))
    p.lineTo((1027, 57))
    p.qCurveTo((1027, -153), (892, -288))
    p.qCurveTo((751, -424), (538, -424))
    p.qCurveTo((280, -424), (149 - 11*s, -224))
    p.lineTo((207 - 11*s, -164 + 17*s))
    p.qCurveTo((338, -285 - 21*s), (500, -285 - 21*s))
    p.qCurveTo((835, -285 - 21*s), (845 - 7*s, -4))
    p.lineTo((845 - 7*s, 128))
    p.qCurveTo((718, -14), (522, -14))
    p.qCurveTo((77 - 5*s, -14), (77 - 5*s, 495))
    p.qCurveTo((77 - 5*s, 758), (222, 939))
    p.qCurveTo((350, 1098), (564, 1098))
    p.closePath()
    # The counter leans into the ear and turns more slowly at the lower left.
    p.moveTo((259 + 7*s, 493))
    p.qCurveTo((259 + 7*s, 123 - 30*s), (536, 123 - 30*s))
    p.qCurveTo((763, 123 - 30*s), (843, 354))
    p.qCurveTo((854, 398), (854, 535))
    p.qCurveTo((854, 946 + 34*s), (594, 946 + 34*s))
    p.qCurveTo((448, 946 + 34*s), (349, 814))
    p.qCurveTo((259 + 7*s, 695), (259 + 7*s, 493))
    p.closePath()
    return p.glyph()


def draw_loop_g(reach):
    """A small upper eye, a bent connecting stroke and a broad lower loop."""
    s = reach
    p = TTGlyphPen(None)
    p.moveTo((524, 1098))
    p.qCurveTo((688, 1098), (789, 1025))
    p.qCurveTo((868, 1107), (1031 + 20*s, 1116))
    p.lineTo((1013 + 14*s, 981 - 17*s))
    p.qCurveTo((911, 1002), (850, 959))
    p.qCurveTo((927, 872), (927, 745))
    p.qCurveTo((927, 578), (805, 468))
    p.qCurveTo((684, 361), (509, 361))
    p.qCurveTo((425, 361), (364, 381))
    p.qCurveTo((299, 327), (336, 287))
    p.qCurveTo((375, 250), (598, 236))
    p.qCurveTo((1039, 212), (1039, -55))
    p.qCurveTo((1039, -218), (886, -326))
    p.qCurveTo((739, -426), (508, -426))
    p.qCurveTo((91, -426), (91, -187))
    p.qCurveTo((91, -45), (289, 74))
    p.qCurveTo((165, 123), (165, 232))
    p.qCurveTo((165, 327), (270, 425))
    p.qCurveTo((108, 524), (108, 710))
    p.qCurveTo((108, 894), (242, 1007))
    p.qCurveTo((351, 1098), (524, 1098))
    p.closePath()
    p.moveTo((279 + 5*s, 733))
    p.qCurveTo((279 + 5*s, 493 - 27*s), (516, 493 - 27*s))
    p.qCurveTo((752, 493 - 27*s), (752, 738))
    p.qCurveTo((752, 965 + 24*s), (542, 965 + 24*s))
    p.qCurveTo((279 + 5*s, 965 + 24*s), (279 + 5*s, 733))
    p.closePath()
    p.moveTo((255 + 5*s, -155))
    p.qCurveTo((255 + 5*s, -301 - 22*s), (519, -301 - 22*s))
    p.qCurveTo((695, -301 - 22*s), (798, -228))
    p.qCurveTo((874, -172), (874, -92))
    p.qCurveTo((874, 39 + 16*s), (599, 57 + 16*s))
    p.qCurveTo((478, 65 + 16*s), (419, 78 + 14*s))
    p.qCurveTo((255 + 5*s, -22), (255 + 5*s, -155))
    p.closePath()
    return p.glyph()


# Offsets from the 0.1 contours, in 2048 units per em. Pull the shoulder
# towards the downstroke, leaving the upright and its serif anchors in place.
SHOULDER = {0:(48,10), 1:(39,14), 2:(-4,-16), 3:(0,-32),
            22:(-12,-39), 23:(36,0), 24:(70,0), 25:(35,0),
            26:(22,18), 38:(0,23), 39:(34,20), 40:(52,10)}
# Each tuple follows one rounded corner from its tip into its stem. Reuse
# those points to draw a bracket, so it is integral to the outline at any size.
CORNERS = {
    'A': [(0, 4, -1), (17, 13, 1)],
    'B': [(0, 3, -1), (7, 4, -1)], 'D': [(6, 9, -1), (13, 10, -1)],
    'E': [(0, 3, -1), (7, 4, -1)],
    'X': [(0, 4, -1), (10, 6, -1), (20, 24, 1), (30, 26, 1)],
    'x': [(0, 4, -1), (10, 6, -1), (22, 26, 1), (32, 28, 1)],
    'y': [(0, 4, -1), (10, 6, -1), (26, 30, 1)],
}

# A beak is the angled finish of an open curve or horizontal stroke.
BEAKS = {
    'C': [(18, 21, 10, -52)], 'G': [(19, 22, 10, -52)],
    'c': [(18, 21, 10, -49)],
    'S': [(8, 11, -8, 54), (39, 42, 8, -54)],
    's': [(8, 10, -8, 47), (35, 38, 8, -47)],
    'Z': [(17, 20, -12, -54), (42, 45, 12, 54)],
    'z': [(11, 14, -8, -49), (30, 33, 8, 49)],
}


def finish_outline(name, glyph, reach):
    points = glyph.coordinates
    for tip, root, side in CORNERS.get(name, []):
        step = 1 if root > tip else -1
        points_in_corner = list(range(tip, root + step, step))
        x, y = points[tip]
        rx, ry = points[root]
        nx, ny = points[(root + step) % (glyph.endPtsOfContours[0] + 1)]
        depth = (50 + 72*reach) * (1 if ny > ry else -1)
        slope = (nx - rx) / (ny - ry)
        end_x = rx + slope * (y - ry)
        length = side * (23 + 35*reach)
        # Two or three off-curve points blend a thin outer edge into the stem.
        points[tip] = (round(x + length), y)
        points[root] = (round(end_x + slope*depth), round(y + depth))
        for j, i in enumerate(points_in_corner[1:-1], start=1):
            t = j / (len(points_in_corner) - 2)
            points[i] = (round(end_x + (1-t)*length + slope*depth*.28*t),
                         round(y + depth*(.21 + .07*t)))
    for first, last, dx, dy in BEAKS.get(name, []):
        for i in range(first, last + 1):
            x, y = points[i]
            points[i] = (round(x + dx*(.55 + .45*reach)), round(y + dy*(.55 + .45*reach)))
    if name in ('o', 'O', 'Q'):
        # Closed bowls carry the pen angle in the counter. Tilt the stress
        # without sticking a spur onto the outer silhouette.
        mid = (glyph.yMin + glyph.yMax) / 2
        for i in range(glyph.endPtsOfContours[0]+1, len(points)):
            x, y = points[i]
            points[i] = (round(x - (y-mid)*(.035 + .035*reach)), y)
    for i, (dx, dy) in (SHOULDER.items() if name in ('n', 'h') else []):
        x, y = points[i]
        points[i] = (x + dx, y + dy)


def fit_letters(font, loop):
    """Set advances first, then kern open shapes against their actual neighbours."""
    glyf, metrics = font['glyf'], font['hmtx']
    widths = {'e': 1005, 'm': 1664, 'p': 1161, 'g': 1070 if loop else 1124}
    families = {name: [name] for name in widths}
    anchor_shift = {'e': -43}
    for name, width in widths.items():
        metrics[name] = width, glyf[name].xMin
    for name in font.getGlyphOrder():
        glyph = glyf[name]
        if not glyph.isComposite():
            continue
        base = glyph.components[0].glyphName
        if base in widths:
            families[base].append(name)
            if base == 'e':
                for mark in glyph.components[1:]:
                    mark.x -= 43
                anchor_shift[name] = -43
            glyph.recalcBounds(glyf)
            metrics[name] = widths[base], glyph.xMin
        elif name == 'oe':
            # Align the two bowls at their original join and fit the new outer edge.
            glyph.components[1].x += 21
            glyph.recalcBounds(glyf)
            metrics[name] = metrics[name][0] - 83, glyph.xMin

    gpos = font['GPOS'].table
    for lookup in gpos.LookupList.Lookup:
        if lookup.LookupType == 4:
            for sub in lookup.SubTable:
                for name, record in zip(sub.BaseCoverage.glyphs, sub.BaseArray.BaseRecord):
                    if name in anchor_shift:
                        for anchor in record.BaseAnchor:
                            if anchor:
                                anchor.XCoordinate += anchor_shift[name]

    pairs = {'et': -59, 'te': -37, 'ee': -9, 'er': -13, 'ea': -15,
             're': -22, 'fe': -16, 'se': -10, 'Me': -15, 'Te': -29,
             'Ve': -17, 'We': -10, 'Ye': -26, 'ze': -16,
             'Up': -24, 'pp': -16, 'rc': -39, 'rs': -42, 'ca': -31, 'as': -16,
             'to': -20, 'ta': -19, 'ot': -29, 'at': -20,
             'ge': -35 if loop else -8}
    if loop:
        pairs.update({'go': -25, 'ga': -25, 'gd': -25, 'gq': -25, 'ng': -16,
                      'eg': -14, 'gf': 45, 'gj': 18})
    # Include accents in the same pairs, including tcaron and accented vowels.
    for code, name in font.getBestCmap().items():
        parts = unicodedata.normalize('NFD', chr(code))
        if len(parts) > 1 and parts[0].isascii() and parts[0].isalpha() and parts[0] not in widths:
            families.setdefault(parts[0], [parts[0]]).append(name)
    adjustments = {}
    for (left, right), amount in pairs.items():
        value = (buildValue({'XAdvance': amount}), None)
        for first in families.get(left, [left]):
            for second in families.get(right, [right]):
                adjustments[first, second] = value
    subtables = buildPairPosGlyphs(adjustments, font.getReverseGlyphMap())
    index = len(gpos.LookupList.Lookup)
    gpos.LookupList.Lookup.append(buildLookup(subtables, flags=8))
    gpos.LookupList.LookupCount += 1
    kern = next(r.Feature for r in gpos.FeatureList.FeatureRecord if r.FeatureTag == 'kern')
    kern.LookupListIndex.append(index)
    kern.LookupCount += 1


def build(base, destination, loop=False):
    font = TTFont(base, recalcTimestamp=False)
    if font['name'].getDebugName(5) != 'Version 0.100':
        raise ValueError('Start from the Guthli 0.1 TTF.')
    glyf = font['glyf']
    # Long s is a composite whose sole stem has no Unicode mapping of its own.
    stem = '_part.f_base'
    deltas, _ = make_variation(glyf[stem], stem)
    font['gvar'].variations[stem] = [TupleVariation({'SERF': (0, 1, 1)}, deltas + [(0, 0)]*4)]
    # Both ends are hybrid. At zero the upright already has a small foot.
    light = instantiateVariableFont(font, {'SERF': 42}, static=True)['glyf']
    full = instantiateVariableFont(font, {'SERF': 88}, static=True)['glyf']
    drawings = {'a': draw_a, 'e': draw_e, 'g': draw_loop_g if loop else draw_g,
                'm': draw_m, 'p': draw_p, 'r': draw_r, 't': draw_t}
    for name, variations in font['gvar'].variations.items():
        if name in drawings:
            low, high = drawings[name](0), drawings[name](1)
        elif variations and not glyf[name].isComposite():
            low, high = light[name], full[name]
            finish_outline(name, low, 0)
            finish_outline(name, high, 1)
        else:
            continue
        assert low.endPtsOfContours == high.endPtsOfContours and low.flags == high.flags
        low.coordinates.toInt()
        high.coordinates.toInt()
        delta = [(b[0]-a[0], b[1]-a[1]) for a, b in zip(low.coordinates, high.coordinates)]
        glyf[name] = low
        low.recalcBounds(glyf)
        font['hmtx'][name] = (font['hmtx'][name][0], low.xMin)
        font['gvar'].variations[name] = [TupleVariation({'SERF': (0, 1, 1)}, delta + [(0, 0)]*4)]
    for name in font.getGlyphOrder():
        glyph = glyf[name]
        if glyph.isComposite():
            glyph.recalcBounds(glyf)
            font['hmtx'][name] = font['hmtx'][name][0], glyph.xMin

    fit_letters(font, loop)
    family = 'Guthli Study Loop' if loop else 'Guthli Study'
    filename = family.replace(' ', '-')
    names = {1:family, 2:'Regular', 3:family+' 0.2.2 Regular',
             4:family+' Regular', 5:'Version 0.202', 6:family.replace(' ', '')+'-Regular',
             10:'Latin study derived from Allo with drawn terminals, open counters and a continuous serif axis.',
             16:family, 17:'Regular'}
    for record in font['name'].names:
        if record.nameID in names:
            record.string = names[record.nameID].encode(record.getEncoding())
        elif record.toUnicode() == 'Sans':
            record.string = 'Hint'.encode(record.getEncoding())
    font['head'].fontRevision = 0.202
    destination.mkdir(parents=True, exist_ok=True)
    font.save(destination/(filename+'.ttf'))
    font.flavor = 'woff2'
    font.save(destination/(filename+'.woff2'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('base_ttf', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    build(args.base_ttf, args.destination)
    build(args.base_ttf, args.destination, loop=True)
