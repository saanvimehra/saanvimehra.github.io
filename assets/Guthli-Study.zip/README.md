# Guthli 0.2.2

This Latin type study builds on Allo by way of Guthli 0.1. The r, m and p share a sloped entry and small bracketed feet. The two shoulders of m are slightly different widths. The a has a curved exit stroke, and the e has an open mouth and a gently rising crossbar. The t has an upturned foot.

Revision 0.2.2 carries a trace of serif through the full axis. Straight strokes have flared ends, and closed bowls such as o have an angled counter. It retains the compact spacing of the 0.2.1 e. Try the pairs in “Numbers” and “Uppercase” at reading size.

**Guthli Study** has the single-storey g. **Guthli Study Loop** replaces it with a small upper bowl and a broad lower loop. Each has its own family name so both TTFs can be installed alongside Guthli. Use the WOFF2 files on the web. Both variable SERF axes run from 0 (hint) to 100 (serif). Each font has one upright weight, and its repertoire is primarily Latin. Devanagari lettering informed its curves.

## Rebuild

The download includes both build recipes. Start with Josh Puckett’s Allo 1.0.3, revision 60992c5e12a4ad5cad41c54cd8dba370163a4828, and use its variable TTF. Allo credits the Inter Project. The SIL Open Font License is included in OFL.txt.

```sh
python3 -m venv .venv
.venv/bin/pip install 'fonttools[woff]==4.68.0'
.venv/bin/python build_font.py /path/to/allo/fonts/variable/AlloVariable.ttf base
.venv/bin/python workshop.py base/Guthli.ttf study
```

The endpoint drawings and spacing adjustments are in `workshop.py`. Each pair of drawings shares the same points and contours so the outlines interpolate continuously.

[Pinned Allo source](https://github.com/joshpuckett/allo/tree/60992c5e12a4ad5cad41c54cd8dba370163a4828)
