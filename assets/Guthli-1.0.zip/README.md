# Guthli 1.0

Guthli is a variable display typeface made for Saanvi Mehra’s personal website. Its name comes from the Hindi word for a fruit stone. The seed-shaped tittle on i and j, asymmetric terminal brackets, and changing bowl contrast are specific to this cut.

Guthli has a looped g. Guthli Open has a single-storey g. Both use the approved 0.2.2 drawings and spacing. Each covers 374 Unicode characters in one upright weight. The SERF axis runs from a hint of serif at 0 to full reach at 100. The outlines build on Josh Puckett’s Allo 1.0.3, which credits the Inter Project. The fonts are distributed under the included SIL Open Font License.

## Use it

On a Mac, open Guthli.ttf and select Install in Font Book. Install Guthli-Open.ttf to use the alternate cut as well. In a design app that supports variable fonts, choose Guthli and adjust Serif reach. For the web, serve the WOFF2 files with your other assets.

```css
@font-face {
  font-family: Guthli;
  src: url("Guthli.woff2") format("woff2");
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}
.wordmark {
  font-family: Guthli, sans-serif;
  font-variation-settings: "SERF" 52;
}
```

## Rebuild from source

Use Python 3.10 or later with fontTools 4.68.0 and Brotli. Download the upstream Allo repository at commit 60992c5e12a4ad5cad41c54cd8dba370163a4828. Run the following from the directory with this recipe.

```sh
python3 -m venv .venv
.venv/bin/pip install 'fonttools[woff]==4.68.0'
.venv/bin/python build_font.py /path/to/allo/fonts/variable/AlloVariable.ttf base
.venv/bin/python workshop.py base/Guthli.ttf release
```

The first script builds the intermediate font and the seed-shaped tittle. The second draws the final letters, fits their spacing, and exports both cuts.

[Allo source](https://github.com/joshpuckett/allo/tree/60992c5e12a4ad5cad41c54cd8dba370163a4828) · [गुठली in Hindwi](https://www.hindwi.org/hindi-dictionary/meaning-of-guthlii)
